package com.gestion.gestion_soutenances;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionSoutenancesApplicationTests {

	@Test
	void contextLoads() {
	}

}
